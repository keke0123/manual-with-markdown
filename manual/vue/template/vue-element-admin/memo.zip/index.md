# Vue-element-admin Memo

* ## 목차

---

## sidebar

> sidebar 사용법

layout/sidebar/index.vue 에서 permission_routes 의 object 를 for 문을 돌려서 메뉴를 만든것을 볼 수 있다. 여기서 permission_routes 는 store 에 정의 되어 있는데...

![sidebar-01](./img/sidebar-01.png)

store/index.vue 에 가보면 getters 라는 오브젝트가 보인다.

![sidebar-02](./img/sidebar-02.png)

이 오브젝트안에는 permission_routes 가 들어있는데 위와 아래의 이미지를 참고하여 보면  permission.routes 라는 것을 알 수 있고, 

![sidebar-03](./img/sidebar-03.png)

이 permission.routes 는 배열로 GenerateRoutes 라는 action 이 호출되었을때 생성된다는 것을 알 수 있고, (GenerateRoutes 가 언제 호출되는지는 이 내용과는 관계 없음으로 확인해보지 않았다.) 이 action 이 실행될때, asyncRoutes(accessedRoutes) 안에 담긴 내용은 설정해놓은 권한을 확인후 constantRoutes 와 합쳐져서 routes 에 담긴다는 것을 알 수 있다. 

![sidebar-04](./img/sidebar-04.png)

asyncRoutes 와 constantRoutes 는 router/index.js 에 명시 되어 있으며 권한을 설정하지 않을 거라면 constantRoutes 에 routes 내용을 명시해 주면 그 내용을 토대로 sidebar 가 생성된다는 것을 알 수 있다.

![sidebar-05](./img/sidebar-05.png)


## icon

> sidebar icon 사용법

router 

![icon-04](./img/icon-05.png)


## Build

> build 시 assets 의 파일 변환 관련

기본적으로 외부 파일은 @/src/assets 넣어서 사용한다.
build 시 webpack.prod.conf.js 의 설정 내용에 따라 /dist/js/chunk-[hash값]으로 변환된다.

![build-assets 관련](./img/build-assets.PNG)

